# -*- coding: utf-8 -*-

from odoo import api ,fields, models


class Payment(models.Model):
    _name = "pie.setup.payment_plan"

    name = fields.Char(string="Plan Name",size=100,required=True)
    active = fields.Boolean('Active', default=True)
    is_percentage = fields.Boolean('Is Deposit a Percentage?')
    deposit = fields.Float(string="Deposit Amount")
    installments_count = fields.Integer(string="count of instalments months") 
    _sql_constraints = [
        ('area_unique', 'unique (name)',
         'This Area already exixts!')]

    @api.constrains('name')
    def _check_duplicate_code(self):
        names = self.search([])
        for c in names:
            if self.name.lower() == c.name.lower() and self.id != c.id:
                raise exceptions.ValidationError("Error: Name must be unique")

    @api.constrains('deposit')
    def _check_positive_deposit(self):
        for record in self:
            if record.deposit < 0:
                raise exceptions.ValidationError("the deposit cannot be negative : %s" % record.deposit)

    @api.constrains('installments_count')
    def _check_positive_installments_count(self):
        for record in self:
            if record.installments_count < 0:
                raise exceptions.ValidationError("the installments count cannot be negative : %s" % record.deposit)