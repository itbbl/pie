# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import pie_setup_area
import pie_setup_bathrooms
import pie_setup_category
import pie_setup_commercial
import pie_setup_finishing
import pie_setup_floor
import pie_setup_hashtag
import pie_setup_label
import pie_setup_property_status
import pie_setup_region
import pie_setup_residental
import pie_setup_rooms
import pie_setup_payment_plan
import pie_setup_property_comment
import pie_setup_property_labels
import pie_setup_service